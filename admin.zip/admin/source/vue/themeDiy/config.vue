<script type="text/javascript">
	export default {
		'style5_2': {
			'color': {
				list: [
					{
						'label': ''
						, 'value': 'red'
						, 'className': 'class-a'
					}
					, {
						'label': ''
						, 'value': '#e70382'
						, 'className': 'class-b'
					}
					, {
						'label': ''
						, 'value': '#08a5a0'
						, 'className': 'class-c'
					}
					, {
						'label': ''
						, 'value': '#e55968'
						, 'className': 'class-d'
					}
					, {
						'label': ''
						, 'value': '#6971a4'
						, 'className': 'class-e'
					}
					, {
						'label': ''
						, 'value': '#b94e8a'
						, 'className': 'class-f'
					}
				]
				, 'selected': 'class-a'
			}
			, 'service': {
				'open': 1
				, 'list': '免郵費,貨到付款,七天鉴赏期'
			}
			, 'countdown': {
				'open': 1
				, 'label': ''
				, 'time_step': '8'
			}
			, 'comment': {
				'open': 0
			}
		}
		, 'style27_2': {
			'countdown': {
				'open': 1
				, 'label': ''
				, 'time_step': '8'
			}
			, 'service': {
				'open': 1
				, list: '服务1,服务2,服务3'
			}
			, 'comment': {
				'open': 1
			}
			, 'flashsale': {
				'open': 1
			}
		}
		, 'style22': {
			'comment': {
				'open': 1
			}
			, 'service': {
				'open': 1
				, list: '服务1,服务2,服务3'
			}
		}
		, 'style27': {
			'countdown': {
				'open': 1
			}
			, 'comment': {
				'open': 1
			}
			, 'service': {
				'open': 1
				, list: '服务1,服务2,服务3'
			}
		}
		, 'style57': {
			'countdown': {
				open: 1
			}
			, 'comment': {
				open: 1
			}
		}
		, 'style32_2': {
			'countdown': {
				'open': 1
				, 'label': '活動倒計時'
				, 'time_step': '8'
			}
			, 'comment': {
				'open': 1
			}
			, 'service': {
				'open': 1
				, list: '服务1,服务2,服务3'
			}
		}
		, 'style64': {
			'comment': {
				'open': 1
			}
			, 'flashsale': {
				'open': 1
			}
		}
		, 'style87': {
			'countdown': {
				'open': 1
				, 'label': '活動倒計時'
				, 'time_step': '8'
			}
			, 'flashsale': {
				'open': 1
			}
		}
	}
</script>