const demo = ({
  commit
}, num) => {
  commit('demo', num)
}



export {
  demo,
}
