<?php
namespace admin\api;

class ErpApi{

	function oldgetProduct(){
		//
	}

	function getProduct(){
		//
	}

	function oldPostOrder(){
		//
	}

	function postOrder(){
		//
	}

}